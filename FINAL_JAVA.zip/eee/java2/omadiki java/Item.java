public class Item
{
    protected String code;
    protected String model;
    protected int year;
    protected String constructor;
    protected float price;
    protected float totalPrice;
    protected float discount;
    protected int quantity;
    protected float percentage;
    

    //constructor 
     public Item(String code, String model,int year,String constructor,float price)
    {
        this.code=code;
        this.model=model;
        this.year=year;
        this.constructor=constructor;
        this.price=price;
        this.totalPrice=price;
        
        

    }
    public void setNewQuantity(int q){
        this.quantity=(this.quantity-q);
    }
    
    public  String getmodel()
    {
        return this.model;
    }
    public  float getPrice(){
        return this.price;
    }
    public int getQuantity(){
        return this.quantity;
    }

    public  float getPercentage(){
        return this.percentage;
    }

    
    
    public String toString(){
        return"Code :"+this.code+"\nModel :"+ this.model+"\nYear :"+this.year+"\nConstractor :"+ this.constructor+"\nPrice :"+this.price+"\nQuantity :"+this.quantity;
    }
}
