public class Camera extends Item
{
    private static final  String type="Action camera";
    private String pixel;
    private String optikozoom;
    private String digitalzoom;
    private String sizescreen;
   
    
    
    //constructor
    public Camera  (String code, String model,int year,String constructor,float price,String pixel,String optikozoom,String digitalzoom,String sizescreen)
    {
        super(code,model,year,constructor,price);
        this.pixel=pixel;
        this.optikozoom=optikozoom;
        this.digitalzoom=digitalzoom;
        this.sizescreen=sizescreen;
        this.quantity=0;
        this.percentage=20;
        
    }
   
    
    public String toString(){
        return super.toString()+"\nType :"+ type+ "\nPixel :"+this.pixel+"\nZoom :"+ this.optikozoom+ "\nDigital Zoom :"+this.digitalzoom+"\n Screen Size :"+this.sizescreen;
    }
    
}