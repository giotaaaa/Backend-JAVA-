public class Washer extends Item
{
    private String energyclass;
    private String capacity;
    private int rpm;
    private String type;
    
    
    


    //constructor
    public  Washer (String code, String model,int year,String constructor,float price,String type,String energyclass,String capacity,int rpm)
    {
        super(code,model,year,constructor,price);
        this.energyclass=energyclass;
        this.type=type;
        this.capacity=capacity;
        this.rpm=rpm;
        this.quantity=8;
        this.percentage=25;
       
 
    }
public String toString(){
    return super.toString()+"\nType :"+ this.type+ "\nEnergy Class :"+this.energyclass+"\nCapacity :"+ this.capacity+ "\nRPM :"+this.rpm;
}
}
