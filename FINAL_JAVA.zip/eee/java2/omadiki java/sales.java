import java.time.LocalDate;
public class sales {
    private int saleNumber;
    private String model;
    private String name;
    private String phone;
    private LocalDate saleDate;
    private float cost;
    
    public sales(int saleNumber, String model, String name,String  phone, LocalDate saleDate, float cost )
    {
        this.saleNumber=saleNumber;
        this.model=model;
        this.name=name;
        this.phone=phone;
        this.saleDate=saleDate;
        this.cost=cost;
    }

    public String toString()
    {
        return "\nSale number is :"+this.saleNumber+"\nModel is :"+this.model+"\nName is :"+this.name+"\nPhone is :"+this.phone+"\nThe date of the sale is : "+this.saleDate+"\nCost is :"+this.cost+"\n";
    }








}
