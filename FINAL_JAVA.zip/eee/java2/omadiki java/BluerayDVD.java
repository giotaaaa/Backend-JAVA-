public class BluerayDVD extends Item
{
    private static final  String type="DVD";
    private String analisi;
    private static final String format="BD-R";
    
    
    //constructor
    public BluerayDVD(String code, String model,int year,String constructor,float price,String analisi)
    {
        super(code,model,year,constructor,price);
        this.analisi=analisi;
        this.quantity=7;
        this.percentage=20;
        

    }
    
    public String toString(){
        return super.toString()+"\nType :"+ type+ "\n Display Resolution :"+this.analisi+"\nFormat :"+ format;
    }
}