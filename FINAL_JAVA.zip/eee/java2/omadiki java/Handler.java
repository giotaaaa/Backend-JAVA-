//koritsia
import java.util.ArrayList;

public class Handler {
    private ArrayList<Item> availableItems = new ArrayList<Item>();
    private ArrayList<Order> orderedItems = new ArrayList<Order>();    
    private ArrayList<sales> soldItems = new ArrayList<sales>();
    private int  ordercounter=0;
    private int salecounter=0;
    
    public void InitAvailable()
    {
        availableItems.add(new BluerayDVD("100","model1",2019,"Manufacturer1",100,"analisi1"));
        availableItems.add(new Camera("200","model2",2023,"Manufacturer1",250,"200","125x","100","4"));
        availableItems.add(new Console("300","model3",2023,"Manufacturer1",500,"cpu1","gpu1","ixos1","storage1"));
        availableItems.add(new Fridges("400","model4",2020,"Manufacturer1",700,"A++","sintirisi1","katapsiksi1"));
        availableItems.add(new TV("500","model5",2022,"Manufacturer1",1000,"size1","analisi1"));
        availableItems.add(new Washer("600","model6",2023,"Manufacturer1",700,"typos1","energyclass1","capacity1",1));

        availableItems.add(new BluerayDVD("101","model7",2023,"Manufacturer1",120,"analisi1"));
        availableItems.add(new Camera("201","model8",2023,"Manufacturer1",300,"pixel1","optikoszoom1","digitalzoom1","screensize2"));
        availableItems.add(new Console("301","model9",2023,"Manufacturer1",600,"cpu1","gpu1","ixos1","storage1"));
        availableItems.add(new Fridges("401","model10",2023,"Manufacturer1",650,"energy1","sintirisi1","katapsiksi1"));
        availableItems.add(new TV("501","model11",2023,"Manufacturer1",800,"size1","analisi1"));
        availableItems.add(new Washer("601","model12",2023,"Manufacturer1",600,"typos1","energyclass1","capacity1",1));
    }
    public Item FindModel(String m){
        
        for ( Item item : availableItems){
            if (m.equals(item.getmodel())){
                System.out.print(item.toString());
                return item;

            }
        }
        return null;
    
   
    }
    public void SetSale(sales ob){
        soldItems.add(ob);
        
        
    }
    public void SetOrder(Order ob){
        orderedItems.add(ob);
        
    }
    public Order FindOrder(int o)
    {
        if(o<=orderedItems.size() && o>=0){
          Order order= orderedItems.get(o);
          System.out.println(order.toString());
          return order;}
        return null;     
    }
    public sales FindSale(int o)
    {
        if(o<=soldItems.size() && o>=0){
          sales sale= soldItems.get(o);
          System.out.println(sale.toString());
          return sale;}
        return null;     
    }
    public int getsizeorder()
    {
        return orderedItems.size();
    }
    public int getsizesale()
    {
        return soldItems.size();
    }
    public int getorderc()
    {   int temp=ordercounter;
         ordercounter++;
         return temp;

        
    }
    public int getsalec()
    {   int temp=salecounter;
         salecounter++;
         return temp;   
    }




}


