public class Fridges extends Item
{
    private static final String type="2doors";
    private String energyclass;
    private String sintirisi;
    private String katapsixi;
    
    

    //constructor
    public Fridges (String code, String model,int year,String constructor,float price,String energyclass,String sintirisi,String katapsixi)
    {
        super(code,model,year,constructor,price);
        this.energyclass=energyclass;
        this.sintirisi=sintirisi;
        this.katapsixi=katapsixi;
        this.quantity=4;
        this.percentage=25;
        
    }
    
    public String toString(){
        return super.toString()+"\nType :"+ type+ "\nEnergy Class :"+this.energyclass+"\nMaintenance :"+ this.sintirisi+ "\nFreezer :"+this.katapsixi;
    }

}