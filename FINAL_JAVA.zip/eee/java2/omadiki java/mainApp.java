//koritsia
import java.util.Scanner;
import java.time.LocalDate;
public class mainApp
{
    private  static boolean done =false; 
    protected static Handler Lista= new Handler();


    public static void menu(String ans)
    {
        Scanner in =new Scanner(System.in);
        String c;
        String t;
        String model;
        int o;
        String name;
        String phone;
        LocalDate saledate;
        LocalDate orderdate;
        float discount;
        float totalcost;
        boolean check=false;
        int choice;
        int year=0;
        int month=0;
        int d=0;
        int q;


        if (ans.equals("0"))
        {
            

            System.out.println();
            System.out.println(" Choose Category :");
            System.out.println("----------------------------------------");
            System.out.println("0.Hxos/Eikona");
            System.out.println("1.Gaming");
            System.out.println("2.Oikiakes Syskeues");
            System.out.print(">");
            
            c= in.nextLine();
            System.out.println();
            /*if(Integer.parseInt(c)>2 || (Integer.parseInt(c))<0)
            {
                System.out.println("invalid option");
                return;
            }*/
            System.out.println(" Choose Type :"); 
            System.out.println("----------------------------------------");

            
                if (c.equals("0"))
                    {
                        System.out.println("0.TVs");
                        System.out.println("1.BlueRay/DVD players");
                        System.out.println("2.Cameras");
                        System.out.print(">");
                        t= in.nextLine();
                        System.out.println();
                    }
                else if(c.equals("1"))
                    {
                        System.out.println("0.Consoles/Handheld Consoles");
                        System.out.print(">");
                        t= in.nextLine();
                        System.out.println();
                    }
                else if(c.equals("2"))
                    {
                        System.out.println("0.Fridges");
                        System.out.println("1.Washers");
                        System.out.print(">");                   
                        t= in.nextLine();
                        System.out.println();
                    }
                    
                    //if1
            System.out.println("Give Model :");
            System.out.println("----------------------------------------");
            System.out.print(">");
            model=in.nextLine();
            System.out.println();
            Item currentItem=Lista.FindModel(model);




            if (currentItem.getQuantity()>=0)
                {
                    System.out.println();
                    System.out.println("\nBuy/Don't Buy ?");
                    System.out.println("----------------------------------------");
                    
                    System.out.println("1. Buy");
                    System.out.println("2. Don't Buy");
                    System.out.print(">");

                    choice=in.nextInt();
                    System.out.println();
            
                    if (choice==1)
                        {
                            System.out.println("Checkout");
                            System.out.println("----------------------------------------");
                            System.out.println("First Name / Last Name :");
                            System.out.print(">");
                            name=in.next();
                            System.out.println("\nPhone Number :");
                            System.out.print(">");
                            phone=in.next();
                            saledate=LocalDate.now();
                            System.out.println("\nQuantity ? :");
                            System.out.print(">");
                            q=in.nextInt();
                            System.out.println();
                
                            if(q<=currentItem.getQuantity())
                                {
                                    discount=(currentItem.getPrice())*((currentItem.getPercentage())/100);
                                    totalcost= ((currentItem.getPrice())-discount)*(q);
                                    System.out.println("Price : "+ currentItem.getPrice()+"€");
                                    System.out.println("Discount Percentage : "+ currentItem.getPercentage());
                                    System.out.println("Discount Amount  : "+ discount+"€");
                                    System.out.println("Total cost :"+totalcost+"€");
                                    System.out.println();
                                    sales obsale= new sales(Lista.getsalec(), model, name, phone, saledate, totalcost);
                                    Lista.SetSale(obsale);
                                    currentItem.setNewQuantity(q);
                                    return;
                                }
                            else if (currentItem.getQuantity()<q)
                                {
                                    System.out.println("Quantity is not enough...");
                                    System.out.println();
                                    System.out.println("\nOrder ?");
                                    System.out.println("----------------------------------------");                        
                                    System.out.println("1. Yes");
                                    System.out.println("2. No");
                                    System.out.print(">");           
                                    choice=in.nextInt();
                                    System.out.println();
                                    if (choice==1)
                                        {
                                            orderdate=LocalDate.now();
                                            int mord=orderdate.getMonthValue();                            
                                            int dord=orderdate.getDayOfMonth();                            
                                            int yord=orderdate.getYear();                     
                                            while(!check)
                                            {
                                                System.out.println("\nArrival Date ? :");
                                                System.out.println("Date? ");
                                                System.out.print(">");
                                                d=in.nextInt();
                                                System.out.println("Month ?");
                                                System.out.print(">");
                                                month=in.nextInt();
                                                System.out.println("Year ?");
                                                System.out.print(">");
                                                year=in.nextInt();
                                                if(year<0 || month<0 || d<0 ||month>12 || d>31)
                                                    System.out.println("Wrong date data...");
                                                int mydays,userDays;
                                                mydays=yord*365+mord*30+dord;
                                                userDays=year*365+month*30+d;
                                                if(mydays>userDays)
                                                {
                                                    System.out.println("Unavailable date... Try  Again ");
                                                    
                                                    
                                                }
                                                else{check=true;}
                                            }// close the control of the date               
                                        //create the order object
                                        discount=(currentItem.getPrice())*((currentItem.getPercentage())/100);
                                        totalcost= ((currentItem.getPrice())-discount)*(q);
                                        Order oborder=new Order(Lista.getorderc(), model, name, phone, orderdate, year+"-"+month+"-"+d, totalcost, "Waiting...");
                                        Lista.SetOrder(oborder);
                                        return;
                       
                                        }//clode the order choice
                                }//klini to if i posotita ==0
                   
                        }//klini to if an ueli na to agorasei 
                }//else if quantity>=0
        }//if(ans.equals("0"))
        else if (ans.equals("1"))
        {
            System.out.println(" Give Order number from 0 to  "+(Lista.getsizeorder()-1)+":");
            o=in.nextInt();
             Order ob=Lista.FindOrder(o);
            System.out.println("Arrival Order / Sale");
            System.out.println("0.Yes");
            System.out.println("1.No");
            int ch=in.nextInt();
            if (ch==0)
                {
                    ob.setstate("The order is DONE...");
                    sales obsale= new sales(Lista.getsalec(), ob.getmodel(), ob.getname(), ob.getphone(), LocalDate.now(), ob.getcost());
                    Lista.SetSale(obsale);
                    return;
                }
            else{
                    return;
                }



        }
        else if (ans.equals("2"))
        {
            System.out.println(" Give sale  number from 0 to  "+(Lista.getsizesale()-1)+":");
            o=in.nextInt();
            sales ob=Lista.FindSale(o);
        }else
        {
            done=true;
        }
    
    }// klini tin menu 
        


    
    
    public static void main(String[] args)
    {
        
        String ans;
        Scanner in =new Scanner(System.in);
        Lista.InitAvailable();
        //--------------------------------------------------------------------------------
        while(!done){
            System.out.println("----------------------------------------");
            System.out.println("0.Available Items");
            System.out.println("1.Ordered Items");
            System.out.println("2.Sold Items");
            System.out.println("3.Exit");
            System.out.println("----------------------------------------");
            System.out.print(">");
            ans= in.nextLine();
            menu(ans);}//while



    }
        
        
}//main
        
