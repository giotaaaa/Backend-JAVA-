public class Console extends Item
{
    private static final String type="PS5";
    private String cpu;
    private String gpu;
    private String sound;
    private String storage;
    
    

    //constructor
    public Console (String code, String model,int year,String constructor,float price,String cpu,String gpu,String sound,String storage)
    {
        super(code,model,year,constructor,price);
        this.cpu=cpu;
        this.gpu=gpu;
        this.sound=sound;
        this.storage=storage;
        this.quantity=10;
        this.percentage=10;
        
    }
    
    
    public String toString(){
        return super.toString()+"\nType :"+ type+ "\nCPU :"+this.cpu+"\nGPU :"+ this.gpu+ "\nSound :"+this.sound+"\nStorage :"+this.storage;
    }

}