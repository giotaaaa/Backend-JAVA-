public class TV extends Item
{   
    private static final String type="Plasma";
    private String size;
    private String analisi;
    private static final String ports="HDMI";
    
    
    
    
    //constructor
    public TV(String code, String model,int year,String constructor,float price,String size,String analisi)
    {   
        super(code,model,year,constructor,price);
        
        this.size=size;
        this.analisi=analisi;
        this.quantity=5;
        this.percentage=20;
        
    }
    public String toString(){
        return super.toString()+"\nType :"+ type+ "\nSize :"+this.size+"\nDisplay Resolution :"+ this.analisi+ "\nPorts :"+ports+"\n";
    }
}