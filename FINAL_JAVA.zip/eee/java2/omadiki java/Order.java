import java.time.LocalDate;
public class Order{

    private int code;
    private String model;
    private String name;
    private String phone;
    private LocalDate orderDate;
    private String deliveryDate;
    private float cost;
    private String state;

    public Order(int code, String model,String name, String phone, LocalDate orderDate, String deliveryDate, float cost, String state )
    {
        this.code=code;//aujwn arithmos gia anazhthsh
        this.model=model;
        this.name=name;
        this.phone=phone;
        this.orderDate=orderDate;
        this.deliveryDate=deliveryDate;
        this.cost=cost;
        this.state=state;
    }

    public String toString()
    {
        return "order code is :" +this.code+"\nmodel is : "+this.model+"\nname is :"+this.name+"\nphone is :" +this.phone+"\norder date is :"+this.orderDate+"\ndelivery date is "+this.deliveryDate+"\ncost is : "+this.cost+"\nstate is : " +this.state+"\n";
    }
    public void setstate(String newstate)
    {
        this.state=newstate;
    }
    public String getmodel()
    {
        return this.model;
    }
    public String getname()
    {
        return this.name;
    }
    public String getphone()
    {
        return this.phone;
    }
    
    public float getcost()
    {
        return this.cost;
    }

}